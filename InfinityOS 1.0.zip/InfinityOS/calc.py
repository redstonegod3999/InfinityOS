import math
print("InfinityOS Calculator Version 1.0")
print("Available operations: ADD, SUBTRACT, MULTIPLY, DIVIDE, POWER TO B")
running = True
while running:
	Num_A = input("Enter number A: ")
	Num_B = input("Enter number B: ")
	Operation = input("Enter operation (+ - * / ^): ")
	if Operation == "+":
		result = Num_A + Num_B
	elif Operation == "-":
		result = Num_A - Num_B
	elif Operation == "*":
		result = Num_A * Num_B
	elif Operation == "/":
		result = Num_A / Num_B
	elif Operation == "^":
		result = math.pow(Num_A, Num_B)
	else:
		print("Wrong operation.")
	if Num_A == "exit":
		break
		exit()
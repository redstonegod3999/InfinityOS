import os
import platform
import socket
from time import strftime
current_os = platform.system()
with open("user_data/username.txt", "r") as f:
	username = f.readline()
print(f"Welcome to InfinityOS, {username}\n\nCurrent date and time is: {strftime("%H:%M:%S %p ") + strftime("%y-%m-%d")}\n\nYour current OS: {current_os}")
running = True
while running:
	dirname = os.path.abspath(os.getcwd())
	main = input(f"{dirname}> ")
	if main == "help":
		print("""
		List of available commands:

		expunge - Deletes a file.
		
		expdir - Deletes a folder/tree.
		
		cd - Moves up or down a folder.
		
		ls - Lists all current files and directories.
		
		move - Moves a file. (To move do mv, example.txt, example/)

		ren - Renames a file.
		
		read - Reads a file. (to read a file do read, example.txt)
		
		help - Lists all current commands within the OS itself.
		
		pwd - Types out/prints current working directory.
		
		makedir - Creates folders (for example makedir then ExampleFolder/)
		
		info - Info about system (version, hostname, etc etc)
		
		calc - Calculator.
		
		vi - Text editor (Linux-friendly command) (Gonna be in 2.0)
		
		echo <text you want to input> - Echoes the text you
		input to the command. (for date and time do echo #date or echo #time)
		
		ping <website> [packets] - Pings the IP or site you input with the amount
		of packets you enter. (Example: ping, 8.8.8.8, 16)
		
		passwd - Changes password based on your input.
		
		usrname - Changes username based on your input.
		
		whoami - Displays current user.
		
		whatismypassword - Displays current password.
			""")
	elif main == "expunge":
		file_to_delete = input("Enter filename to delete (be careful not to destroy your OS): ")
		if current_os == "Windows":
			os.system(f"del {file_to_delete}")
		else:
			os.system(f"rm {file_to_delete}")
	elif main == "expdir":
		folder_to_delete = input("Enter foldername to delete (be careful not to destroy your OS): ")
		if current_os == "Windows":
			os.system(f"rd {folder_to_delete}")
		else:
			os.system(f"rm {folder_to_delete}")
	elif main == "makedir":
		folder_to_create = input("Enter folder to create: ")
		os.system(f"mkdir {folder_to_create}")
	elif main == "cd":
		change_folder = input("Enter folder to move into: ")
		if os.path.exists(change_folder):
			os.chdir(change_folder)
		else:
			print("Folder not found.")
	elif main == "ls":
		if current_os == "Windows":
			os.system("dir")
		else:
			os.system("ls")
	elif main == "move":
		file_to_move = input("Enter file to move: ")
		foldername = input("Enter folder name to move file into: ")
		if os.path.exists(foldername):
			os.system(f"move {file_to_move} {foldername}/")
		else:
			print("Folder not found.")
	elif main == "ren":
		file_to_rename = input("Enter file to rename: ")
		new_name = input("Enter new name of file: ")
		if current_os == "Windows":
			os.system(f"rename {file_to_rename} {new_name}")
		else:
			os.system(f"mv {file_to_rename} {new_name}")
	elif main == "read":
		file_to_read = input("Enter file to read: ")
		if current_os == "Windows":
			os.system(f"type {file_to_read}")
		else:
			os.system(f"cat {file_to_read}")
	elif main == "pwd":
		if current_os == "Windows":
			os.system("cd")
		else:
			os.system("pwd")
	elif main == "info":
		print(f"""
		OS Type: {current_os},
		Architecture: {platform.machine()},
		System name: {socket.gethostname()},
		Platform info: {platform.platform()}
			""")
	elif main == "whoami":
		print(f"Your current username: {username}")
	elif main == "whatismypassword":
		with open("user_data/password.txt", "r") as f:
			password = f.readline().strip()
		print(f"Your current password: {password}")
	elif main == "usrname":
		new_username = input("Please enter new username: ")
		with open("user_data/username.txt", "w") as f:
			f.truncate()
			f.writelines(new_username)
	elif main == "passwd":
		new_password = input("Please enter new password: ")
		with open("user_data/password.txt", "w") as f:
			f.truncate()
			f.writelines(new_password)
	elif main == "echo":
		echo_text = input("Enter text to echo out: ")
		print(f"{echo_text}\n")
	elif main == "calc":
		os.startfile("calc.py")
	elif main == "ping":
		address_to_ping = input("Enter IP address/URL: ")
		packets = input("Enter packet amount: ")
		if current_os == "Windows":
			os.system(f"ping {address_to_ping} /n {packets}")
		else:
			os.system(f"ping {address_to_ping} {packets}")
	elif main == "exit":
		break
		exit()
	else:
		print("Wrong Command.")